package com.cg.project.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.project.beans.UserBean;


@WebServlet("/PageInfoServlet")
public class PageInfoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public void init()  {
	}
	public void destroy() {
		
	}
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter writer = response.getWriter();
		writer.println("<html>");
		writer.println("<body>");
		writer.println("<div>");
		writer.println("<form name='Infoform' action='PageInfoServlet2' method='post'>");
		writer.println("<table>");
		writer.println("<tr>");
		writer.println("<td>Enter firstName :- </td>");
		writer.println("<td><input type='text' name='firstName'>");
		writer.println("</tr>");
		writer.println("<tr>");
		writer.println("<td>Enter lastName :- </td>");
		writer.println("<td><input type='text' name='lastName'>");
		writer.println("</tr>");
		writer.println("<tr>");
		writer.println("<td><input type='submit' name='submit'>");
		writer.println("</tr>");
		writer.println("</table>");
		writer.println("</form");
		writer.println("</div");
		writer.println("</body");
		writer.println("</html");
	}
}