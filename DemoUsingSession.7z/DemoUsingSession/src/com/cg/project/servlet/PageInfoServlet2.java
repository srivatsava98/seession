package com.cg.project.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.project.beans.UserBean;


@WebServlet("/PageInfoServlet2")
public class PageInfoServlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public void init()  {
		System.out.println("init(ServletConfig config)");
	}
	public void destroy() {
		System.out.println("destroy()");
	}
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String firstName= request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		UserBean userBean = new UserBean(firstName, lastName);
		HttpSession session = request.getSession();
		session.setAttribute("userBean", userBean);
		PrintWriter writer = response.getWriter();
		writer.println("<html>");
		writer.println("<body>");
		writer.println("<div>");			
		writer.println("<p>firstName:-"+firstName+"</p>");
		writer.println("<p>lastName:-"+lastName+"</p>");
		writer.println("<form name='Servoform' action='PageServletInfo3' method='post'>");
		writer.println("<table>");
		writer.println("<tr>");
		writer.println("<td>Enter city :- </td>");
		writer.println("<td><input type='text' name='city'>");
		writer.println("</tr>");
		writer.println("<tr>");
		writer.println("<td>Enter state :- </td>");
		writer.println("<td><input type='text' name='state'>");
		writer.println("</tr>");
		writer.println("<tr>");
		writer.println("<td><input type='submit' name='submit'>");
		writer.println("</tr>");
		writer.println("</table>");
		writer.println("</form");
		writer.println("</div");
		writer.println("</body");
		writer.println("</html");
		
	}
}
