package com.cg.project.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.project.beans.UserBean;

@WebServlet("/PageServletInfo3")
public class PageInfoServlet3 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public void init( )   {
		System.out.println("init(ServletConfig config)");
	}
	public void destroy() {
		System.out.println("destroy()");
	}
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String city = request.getParameter("city");
		String state = request.getParameter("state");
		HttpSession session = request.getSession();
		UserBean userBean2 =(UserBean)session.getAttribute("userBean2");
		userBean2.setCity(city);
		userBean2.setState(state);
		PrintWriter writer = response.getWriter();
		writer.println("<html>");
		writer.println("<body>");
		writer.println("<div>");
		writer.println("<p>firstName:-"+userBean2.getFirstName()+"</p>");
		writer.println("<p>lastName:-"+userBean2.getLastName()+"</p>");
		writer.println("<p>email:-"+city+"</p>");
		writer.println("<p>phoneNo:-"+state+"</p>");
		writer.println("<form name='Serform' action='PageServletInfo4' method='post'>");
		writer.println("<table>");
		writer.println("<tr>");
		writer.println("<td>Enter email :- </td>");
		writer.println("<td><input type='text' name='email'>");
		writer.println("</tr>");
		writer.println("<tr>");
		writer.println("<td>Enter phoneNo :- </td>");
		writer.println("<td><input type='text' name='phoneNo'>");
		writer.println("</tr>");
		writer.println("<tr>");
		writer.println("</tr>");
		writer.println("<tr>");
		writer.println("<td><input type='submit' name='submit'>");
		writer.println("</tr>");
		writer.println("</table>");
		writer.println("</form");
		writer.println("</div");
		writer.println("</body");
		writer.println("</html");
		session.setAttribute("userBean2", userBean2);
		}
}


