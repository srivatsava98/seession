package com.cg.project.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.project.beans.UserBean;

@WebServlet("/PageServletInfo4")
public class PageInfoServlet4 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public void init()  {
		System.out.println("init(ServletConfig config)");
	}
	public void destroy() {
		System.out.println("destroy()");
	}
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String email = request.getParameter("email");
		String phoneNo = request.getParameter("phoneNo");
		HttpSession session = request.getSession();
		UserBean userBean3 =(UserBean)session.getAttribute("userBean3");
		userBean3.setEmail(email);
		userBean3.setPhoneNo(phoneNo);
		PrintWriter writer = response.getWriter();
		writer.println("<html>");
		writer.println("<body>");
		writer.println("<div>");
		writer.println("<p>firstName:-"+userBean3.getFirstName()+"</p>");
		writer.println("<p>lastName:-"+userBean3.getLastName()+"</p>");
		writer.println("<p>city:-"+userBean3.getCity()+"</p>");
		writer.println("<p>state:-"+userBean3.getState()+"</p>");
		writer.println("<p>email:-"+email+"</p>");
		writer.println("<p>phoneNo:-"+phoneNo+"</p>");
		writer.println("</div");
		writer.println("</body");
		writer.println("</html");
	}
}
